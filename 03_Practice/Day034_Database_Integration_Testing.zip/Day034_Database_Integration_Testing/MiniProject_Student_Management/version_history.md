# Version History — Student Management System

Full changelog for every version of this project: **what** changed, **why** it was changed, **how** it was implemented, **where** in the codebase, and **when** (which day of the course).

## v24 - Day 034: Database Integration Testing

**When:** Day 034  
**Theme:** Deep-dive into database integration testing patterns — transaction lifecycle, `TRUNCATE` vs `ROLLBACK` cleanup strategies, constraint failure verification, atomicity experiments, and test suite isolation. 12 new integration tests added, bringing the suite total to 39.

### What Changed

| Area | Before (v23) | After (v24) |
| ---- | ------------- | ------------ |
| **`tests/integration/test_student_repository.py`** | 5 integration tests | 17 integration tests (+12 from Day 034) |
| **`TestConstraintFailures`** | — | 2 tests: UNIQUE email violation, PRIMARY KEY collision |
| **`TestTransactionRollback`** | — | 2 tests: rollback leaves no data, committed data survives |
| **`TestAtomicity`** | — | 1 test: partial write in failed transaction does not persist |
| **`TestTransactionAwareFixture`** | — | 2 tests: BEGIN→Test→ROLLBACK `db_transaction` fixture demo |
| **`TestFailureCleanupDrill`** | — | 2 tests: fixture teardown runs even when test raises |
| **`TestSuiteIsolation`** | — | 3 tests: tests are order-independent |
| **`db_transaction` fixture** | — | New session-level fixture demonstrating BEGIN/ROLLBACK pattern |
| **Total test count** | 27 | 39 |

### Why

Day 033 proved that integration tests can verify real SQL queries. Day 034 goes deeper into the **transaction model** underlying those tests:

1. **Constraint failures** must be proven with a real database. A `MagicMock` can only simulate a raised exception — it cannot verify that the UNIQUE or PRIMARY KEY constraint actually exists in the schema and is enforced by PostgreSQL.

2. **TRUNCATE vs ROLLBACK** is an architectural decision, not just a style choice. TRUNCATE commits data and physically removes it afterward; ROLLBACK means data never commits. Each has different performance characteristics and infrastructure requirements.

3. **Atomicity** ("all or nothing") is one of the four ACID guarantees. The `TestAtomicity` test concretely demonstrates that a successfully executed `INSERT A` inside a transaction is rolled back when a subsequent `INSERT B` in the same transaction fails — proving there is no "partial commit" state.

4. **Fixture teardown is unconditional**. Unlike a `try/finally` in the test body, pytest's fixture teardown runs even when the test body crashes. This is the engineering reason to put cleanup in fixtures, not in tests.

5. **Isolation must be structural, not assumed**. The `TestSuiteIsolation` class proves that tests do not share state by verifying each test sees exactly the data it inserted — regardless of execution order.

### How

**Transaction-aware `db_transaction` fixture:**

```python
@pytest.fixture
def db_transaction(db_helper: DatabaseHelper):
    with db_helper._pool.connection() as conn:
        conn.autocommit = False   # BEGIN is implicit on first statement
        yield conn
        conn.rollback()           # TEARDOWN: always roll back
```

The fixture yields a connection inside an open transaction. All SQL on that connection participates. When the fixture teardown runs (always, even on failure), it issues `ROLLBACK`, discarding everything. This demonstrates the cleanest possible test isolation when the repository accepts an external connection.

**Constraint failure test:**

```python
def test_duplicate_email_raises_exception(self, repo):
    repo.add_student(Student_model(email="duplicate@example.com", ...))
    with pytest.raises(Exception) as exc_info:
        repo.add_student(Student_model(email="duplicate@example.com", ...))
    assert any(k in str(exc_info.value).lower()
               for k in ["unique", "duplicate", "violat", "constraint"])
```

**Atomicity experiment:**

```python
def test_partial_write_is_rolled_back(self, db_helper):
    email_a = email_b = "atomic.a@example.com"  # same email → UNIQUE violation

    try:
        with db_helper._pool.connection() as conn:
            conn.autocommit = False
            with conn.cursor() as cur:
                cur.execute("INSERT ... VALUES (101, ..., email_a)")  # succeeds
                cur.execute("INSERT ... VALUES (102, ..., email_b)")  # raises!
            conn.commit()
    except Exception:
        pass   # UniqueViolation — auto rollback happened

    # Verify A is ALSO absent (not just B)
    count = fresh_conn.execute("SELECT COUNT(*) FROM test_students WHERE id IN (101, 102)")
    assert count == 0   # PASSES — neither A nor B persists
```

### Where

```
tests/integration/test_student_repository.py   extended: +12 tests, db_transaction fixture,
                                                           6 new test classes
```

---

## v23 — Day 033: Automated Testing

**When:** Day 033  
**Theme:** Build a three-tier test suite (unit / integration / API) from scratch using `pytest`, `unittest.mock`, and FastAPI's `TestClient`. Exercises 1–11 exercised across all three layers with 27 tests passing end-to-end.

### What Changed

| Area | Before (v22) | After (v23) |
| ---- | ------------- | ------------ |
| **`tests/`** | Did not exist | New directory with `__init__.py`, `conftest.py`, and three sub-packages |
| **`tests/conftest.py`** | — | Shared fixtures: `sample_student`, `mock_student_service`, `mock_db_helper`, `api_client` |
| **`tests/unit/test_student_service.py`** | — | 11 unit tests covering `StudentService` get/add/delete with `MagicMock` |
| **`tests/integration/test_student_repository.py`** | — | 5 integration tests against real PostgreSQL using isolated `test_students` table |
| **`tests/api/test_student_routes.py`** | — | 11 API tests via FastAPI `TestClient` + `dependency_overrides` |
| **App Version** | `15.0.0` | `16.0.0` |

### Why

Before Day 033 the project had zero automated tests. Every change required running the full Docker stack and manually hitting endpoints in Swagger UI — slow, error-prone, and impossible to do in CI.

Three separate test categories are needed because:

1. **Unit tests** (no DB, no network): Prove that `StudentService` business logic is correct — validation raises `ValueError`, `None` from repository becomes `StudentNotFoundException`, and every id is forwarded to the repository unchanged. These run in milliseconds and require no infrastructure.

2. **Integration tests** (real local PostgreSQL): Prove that the SQL queries in `PostgresStudentRepository` are correct — the `INSERT` actually persists data, `SELECT` fetches it in the right shape, `DELETE` removes it, and missing-id lookups return `None`. Mocking the DB in these tests would give false confidence.

3. **API tests** (TestClient + mocks): Prove the HTTP contract — correct status codes (200, 201, 404, 400), correct JSON response shapes, and that global exception handlers (`StudentNotFoundException → 404`, `ValueError → 400`) fire correctly over the wire.

### How

**Unit tests — `MagicMock` pattern:**

```python
@pytest.fixture
def mock_repo():
    return MagicMock()

@pytest.fixture
def service(mock_repo):
    return StudentService(repository=mock_repo)

def test_raises_student_not_found_when_missing(service, mock_repo):
    mock_repo.get_student_by_id.return_value = None
    with pytest.raises(StudentNotFoundException) as exc_info:
        service.get_student_by_id(999)
    assert exc_info.value.student_id == 999
```

**Integration tests — isolated table with proxy cursor:**

```python
# Redirect all SQL from 'students' to 'test_students' without touching production code.
class _SwappingCursor:
    def execute(self, sql: str, params=None):
        swapped = re.sub(r'\bstudents\b', TEST_TABLE, sql)
        return self._cur.execute(swapped, params)
    def __getattr__(self, name):
        return getattr(self._cur, name)
```

psycopg's `Cursor` is a C extension — its attributes are read-only, so direct monkey-patching (`cur.execute = ...`) raises `AttributeError`. The proxy pattern wraps the cursor at the Python level.

**API tests — `dependency_overrides` + `unittest.mock.patch`:**

```python
# Override the FastAPI DI chain so the mock service handles all requests:
app.dependency_overrides[get_student_service] = lambda: mock_student_service

# Also patch the module-level _db_helper singleton so the lifespan's direct
# call to get_db_helper() doesn't try to connect to Docker:
with patch("dependencies._db_helper", mock_db_helper):
    with TestClient(app, raise_server_exceptions=False) as client:
        yield client
```

Key insight: `dependency_overrides` only intercepts code routed through FastAPI's `Depends()`. The lifespan calls `get_db_helper()` directly — a module-level singleton — so it must be patched with `unittest.mock.patch` instead.

**Shared conftest.py fixtures:**

```python
@pytest.fixture
def sample_student():
    return Student_response_model(id=1, name="Alice Test", age=22, city="Mumbai",
                                  email="alice.test@example.com")

@pytest.fixture
def mock_db_helper():
    mock = MagicMock()
    mock.open_pool.return_value = None
    mock.close_pool.return_value = None
    return mock
```

### Where

| File | Action | Purpose |
|------|--------|---------|
| `tests/__init__.py` | **NEW** | Package marker; describes the three test categories |
| `tests/conftest.py` | **NEW** | Shared fixtures: `sample_student`, `mock_student_service`, `mock_db_helper`, `api_client` |
| `tests/unit/__init__.py` | **NEW** | Unit package marker |
| `tests/unit/test_student_service.py` | **NEW** | 11 tests for `StudentService` using `MagicMock` |
| `tests/integration/__init__.py` | **NEW** | Integration package marker |
| `tests/integration/test_student_repository.py` | **NEW** | 5 tests for `PostgresStudentRepository` against real local PostgreSQL |
| `tests/api/__init__.py` | **NEW** | API package marker |
| `tests/api/test_student_routes.py` | **NEW** | 11 tests for HTTP routes via FastAPI `TestClient` |

### Test Results

```
============================= test session starts =============================
platform win32 -- Python 3.14.5, pytest-8.3.3
collected 27 items

tests/api/   ... 11 passed
tests/integration/ ... 5 passed
tests/unit/  ... 11 passed

======================== 27 passed, 1 warning in 8.78s ========================
```

| Category | Count | Speed | Infrastructure Needed |
|----------|-------|-------|-----------------------|
| unit/ | 11 | ~1.8 s | None |
| integration/ | 5 | ~14 s | Local PostgreSQL |
| api/ | 11 | ~0.7 s | None |
| **Total** | **27** | **~8.8 s** | — |

---

## v22 — Day 029: Docker Deployment

**When:** Day 029  
**Theme:** Production hardening — introduce a non-root user (`appuser`) in the Dockerfile, tighten `.dockerignore` to exclude `.git` and other missing patterns, verify the complete image contents, run a full end-to-end smoke test through every application layer, exercise the container lifecycle, and drill deliberate failure troubleshooting.

### What Changed

| Area                        |                              Before (v21) | After (v22)                                                                                                         |
| --------------------------- | -----------------------------------------: | ------------------------------------------------------------------------------------------------------------------- |
| **`Dockerfile`**            | Running as `root` (default)               | `useradd --system appuser` + `USER appuser`; `COPY --chown=appuser:appuser`; all comments fully rewritten           |
| **`.dockerignore`**         | Missing `.git`, `compose.yaml`, `.gitignore`, `.idea/` | All missing patterns added; full comment block explaining why each exclusion matters                 |
| **`compose.yaml` header**   | Day 028 note only                         | Day 029 note added (non-root, dockerignore, smoke test)                                                             |
| **App Version**             | `14.0.0`                                  | `15.0.0`                                                                                                            |

### Why

After Days 025–028 the stack is functionally correct — but Day 029 is about **production readiness**:

1. **Non-root user**: The default Docker behaviour runs all processes as `root` inside the container. If an attacker exploits the application (e.g., RCE via a deserialization vulnerability), they inherit root privileges on the container's kernel namespace — a severe security risk. Running as `appuser` (UID assigned by the OS, no password, no login shell) limits the blast radius to the container's own filesystem.

2. **Clean build context**: `.git` was missing from `.dockerignore`. This meant every build was sending hundreds of MB of git history to the Docker daemon unnecessarily. More critically, git history can contain secrets from past commits (removed credentials, old API keys) — these should never reach the image layer cache.

3. **Verified image purity**: `docker image inspect` confirmed the image contains exactly: Python runtime + pip packages + application code — no `.venv`, no `__pycache__`, no logs, no `.env`.

4. **Failure drill**: A deliberate `DB_HOST=localhost` break was reproduced and resolved using the standard troubleshooting workflow, proving the diagnostic toolset works end-to-end.

### How

**Dockerfile — non-root user:**

```dockerfile
# Before (implicit root):
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]

# After:
RUN useradd --system --no-create-home --shell /bin/false appuser \
    && chown -R appuser:appuser /app

USER appuser

COPY --chown=appuser:appuser . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Why `useradd` not `adduser`: `adduser` on Debian-based images is interactive (prompts for Full Name, Room Number, etc.) even with `--disabled-password`. `useradd` is the low-level, always-silent utility.

**Verification:**

```bash
docker compose exec api whoami
# Output: appuser  ✅
```

**`docker image inspect` key output:**

```
Size:        365MB
WorkingDir:  /app
User:        appuser
ExposedPorts: map[8000/tcp:{}]
Cmd:          [uvicorn main:app --host 0.0.0.0 --port 8000]
```

**`.dockerignore` additions (previously missing):**

```
.git               ← was missing — git history should never reach the image
.gitignore
.gitattributes
compose.yaml       ← build-time file, not needed at runtime
compose.yml
docker-compose.yml
docker-compose.yaml
.idea/
*.swp / *.swo
```

**Container lifecycle verified (Exercise 6 & 7):**

```bash
# Stop/start — db stays healthy throughout
docker compose stop api     → api stopped, db remains healthy
docker compose start api    → depends_on re-evaluated, api starts after db healthy

# Full down/up — named volume persists data
docker compose down         → containers + network removed, volume PRESERVED
docker compose up -d        → network + containers recreated, existing data intact
```

**Failure drill (Exercise 9):**

| Step              | Command / Observation                                      |
| ----------------- | ---------------------------------------------------------- |
| Inject fault      | `DB_HOST=localhost` in `.env`                              |
| Symptom           | api starts but fails all DB queries (connection refused)   |
| `compose ps`      | api `Up` but requests fail (exit 500)                      |
| `compose logs api`| `connection refused` / `host not found` errors             |
| `compose config`  | Confirms `DB_HOST: localhost` in resolved config           |
| Root cause        | `localhost` = api's own loopback; Postgres is in `db`      |
| Fix               | Restore `DB_HOST=db` in `.env`                             |
| `compose up -d`   | Stack healthy; all endpoints return 200                    |

### Where

```
Dockerfile         ← useradd + USER appuser + COPY --chown; full comment rewrite
.dockerignore      ← .git, compose.yaml, .gitignore, .idea/, swap files added; full comment block
compose.yaml       ← header: Day 029 note added
.env               ← APP_VERSION bumped to 15.0.0
README.md          ← Docker Deployment (Day 029) feature section added
version_history.md ← this v22 entry added
```

---

## v21 — Day 028: Docker Internal Networking


**When:** Day 028  
**Theme:** Networking clarity — document and verify the Docker bridge network that Compose creates automatically; understand service-name DNS resolution, why `localhost` fails between containers, and the distinction between internal (api↔db) and external (host↔db) port paths.

### What Changed

| Area                      |        Before (v20) | After (v21)                                                                                        |
| ------------------------- | ------------------: | -------------------------------------------------------------------------------------------------- |
| **`compose.yaml` header** |  Day 027 notes only | Full end-to-end traffic flow diagram added; Day 028 note; 3 new diagnostic commands in usage list  |
| **`api` service comment** |  No networking note | Networking note added: explains why `DB_HOST=db` works and why `localhost` would fail              |
| **`db` ports comment**    | Single-line comment | Expanded: explicitly documents internal path (api→db:5432) vs external path (host→localhost:5433)  |
| **`networks:` section**   |      Not documented | Full documentation block added at bottom of compose.yaml: driver, subnet, DNS, diagnostic commands |
| **App Version**           |            `13.0.0` | `14.0.0`                                                                                           |

### Why

Day 028 focuses on understanding Docker's internal networking model — specifically how service-name DNS works and why `localhost` inside a container is not the same as another container. The key insight:

- Each container has its own network namespace with its own loopback (`127.0.0.1`).
- `localhost` inside `api` resolves to `api`'s own loopback — Postgres is not there.
- `db` resolves to the PostgreSQL container's IP via Docker's embedded DNS server (`127.0.0.11`).
- Container IPs are dynamic (reassigned on every `docker compose up`); service names are stable.
- The `db` published port (`5433:5432`) serves host-side tools only. The api uses the internal `db:5432` path through the bridge network — no port mapping needed for container-to-container traffic.

### How

No application code changes. The changes are entirely in `compose.yaml` comments and documentation.

**Live `docker network inspect` output (actual run):**

```
Name:   miniproject_student_management_default
Driver: bridge
Subnet: 172.18.0.0/16
Gateway: 172.18.0.1

Containers:
  miniproject_student_management-api-1  →  172.18.0.3
  miniproject_student_management-db-1   →  172.18.0.2
```

**Live verification from inside the api container:**

```bash
docker compose exec api sh -c "env | grep DB_HOST; cat /etc/resolv.conf"
```

Output:

```
DB_HOST=db

nameserver 127.0.0.11     ← Docker's embedded DNS resolver
options ndots:0
```

`127.0.0.11` is Docker's internal DNS server. It resolves `db` → `172.18.0.2` (the PostgreSQL container's IP on the bridge network).

**Full end-to-end traffic flow:**

```
Browser
  |
  | http://localhost:8000
  v
Windows Host
  |
  | 8000:8000 port mapping
  v
FastAPI Container (api, 172.18.0.3)
  |
  | DB_HOST=db → Docker DNS (127.0.0.11) → 172.18.0.2
  v
Docker Bridge Network (miniproject_student_management_default)
  |
  v
PostgreSQL Container (db, 172.18.0.2) port 5432 internal
  |
  v
PostgreSQL Server
```

**Host-side connection path (for pgAdmin / psql):**

```
Windows Host
  |
  | localhost:5433 → published port mapping → db container:5432
  v
PostgreSQL Container
```

**Diagnostic commands documented:**

```bash
docker network ls                                                  # list all networks
docker network inspect miniproject_student_management_default      # inspect IPs, aliases, subnet
docker compose exec api sh                                         # enter api container
  → env | grep DB_HOST       # confirm DB_HOST=db
  → cat /etc/resolv.conf     # confirm nameserver 127.0.0.11
```

### Where

```
compose.yaml       ← header: end-to-end traffic flow diagram + Day 028 note + 3 new commands
                     api service: networking note added (why 'db', not 'localhost')
                     db ports: expanded comment (internal vs external path)
                     bottom: Networks documentation block added
.env               ← APP_VERSION bumped to 14.0.0
README.md          ← Docker Internal Networking (Day 028) feature section added
version_history.md ← this v21 entry added
```

---

## v20 — Day 027: Docker Compose Configuration

**When:** Day 027  
**Theme:** Configuration maturity — add an explicit `environment:` block to the `api` service with `${VAR}` interpolation so each variable is individually visible and overridable; add `restart: on-failure` so Docker automatically recovers from API crashes; document environment-variable precedence and the dev-vs-prod bind-mount distinction.

### What Changed

| Area                         |                             Before (v19) | After (v20)                                                                                               |
| ---------------------------- | ---------------------------------------: | --------------------------------------------------------------------------------------------------------- |
| **`api` environment config** | `env_file: .env` only (vars not visible) | `env_file: .env` + explicit `environment:` block listing all vars with `${VAR}` interpolation             |
| **`api` restart policy**     |              No restart policy (default) | `restart: on-failure` — auto-restart on any non-zero exit; no restart on clean stop                       |
| **Header comment**           |                        Day 026 note only | Day 027 note added; full precedence table documented; `docker compose config` command added to usage list |
| **App Version**              |                                 `12.0.0` | `13.0.0`                                                                                                  |

### Why

After Day 026 the api's environment was loaded entirely via `env_file: .env` — effective but opaque. Any reader of `compose.yaml` could not tell which variables the service used without opening `.env`. Additionally:

- **Overridability**: `env_file` injects a whole file at once. To change a single variable per deployment (e.g., `LOG_LEVEL=DEBUG` for a dev run) you had to edit `.env`. An explicit `environment:` key in `compose.yaml` overrides `env_file` for that specific key — enabling per-service, per-run overrides without touching the shared `.env` file.
- **Crash recovery**: without a restart policy, a crashing FastAPI process (e.g., OOM, unhandled exception at startup, bad migration) leaves the container permanently stopped. `restart: on-failure` lets Docker recover automatically from transient failures.

### How

**Explicit `environment:` block added to `api`:**

```yaml
api:
  env_file:
    - .env # bulk-load all .env vars as defaults
  environment:
    APP_NAME: ${APP_NAME} # ${VAR} is filled by Compose from .env at project level
    APP_VERSION: ${APP_VERSION}
    DEBUG: ${DEBUG}
    JWT_SECRET_KEY: ${JWT_SECRET_KEY}
    JWT_ALGORITHM: ${JWT_ALGORITHM}
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: ${JWT_ACCESS_TOKEN_EXPIRE_MINUTES}
    DB_HOST: ${DB_HOST}
    DB_PORT: ${DB_PORT}
    DB_NAME: ${DB_NAME}
    DB_USER: ${DB_USER}
    DB_PASSWORD: ${DB_PASSWORD}
    DB_POOL_MIN_SIZE: ${DB_POOL_MIN_SIZE}
    DB_POOL_MAX_SIZE: ${DB_POOL_MAX_SIZE}
    LOG_LEVEL: ${LOG_LEVEL}
```

**Restart policy added:**

```yaml
api:
  restart: on-failure # Docker restarts the container on any non-zero exit code
```

**Environment variable precedence (highest → lowest inside a running container):**

```
1. environment: key in compose.yaml          ← wins
2. env_file: file listed in compose.yaml
3. ENV instruction in Dockerfile
4. Image default (built-in)
```

**`docker compose config` — resolve and audit:**

```bash
docker compose config
```

This command processes `compose.yaml` + `.env`, substitutes all `${VAR}` placeholders, and prints the fully-resolved YAML. Useful for verifying that the right values will reach each container before running the stack.

**Dev vs Prod bind mount (Exercise 6 concept):**

| Mode        | Source of code   | Bind mount?        | Why                                                                       |
| ----------- | ---------------- | ------------------ | ------------------------------------------------------------------------- |
| Development | Host filesystem  | ✅ Yes (`./:/app`) | Code changes are visible to the container instantly; no rebuild needed    |
| Production  | Baked into image | ❌ No              | Image is immutable and reproducible; host code cannot accidentally differ |

This project currently uses a logs bind mount (`./logs:/app/logs`) for log persistence, but does **not** bind-mount source code — consistent with production guidance.

### Where

```
compose.yaml       ← api: explicit environment: block with ${VAR} interpolation added
                     api: restart: on-failure added
                     header: Day 027 note, precedence table, and new commands documented
.env               ← APP_VERSION bumped to 13.0.0
README.md          ← Docker Compose Configuration (Day 027) feature section added
version_history.md ← this v20 entry added
```

---

## v19 — Day 026: Docker Health Checks

**When:** Day 026  
**Theme:** Reliability — add a `pg_isready` health check to the `db` service so Docker knows exactly when PostgreSQL is ready to accept connections; upgrade `api`'s `depends_on` to `condition: service_healthy` so the FastAPI container never starts before the database is truly ready.

### What Changed

| Area                           |                                    Before (v18) | After (v19)                                                                            |
| ------------------------------ | ----------------------------------------------: | -------------------------------------------------------------------------------------- |
| **`db` healthcheck**           |                                     Not present | `pg_isready` probe — interval 5 s, timeout 5 s, retries 5, start_period 10 s           |
| **`api` depends_on**           | `depends_on: - db` (container-start order only) | `depends_on: db: condition: service_healthy` — api waits for db's health check to pass |
| **Race condition**             | api could fail if Postgres hadn't finished init | Eliminated — Compose holds api until db is `healthy`                                   |
| **`docker compose ps` output** |               Shows `running` for both services | Shows `running (healthy)` for db; api only reaches `running` after db is healthy       |
| **App Version**                |                                        `11.0.0` | `12.0.0`                                                                               |

### Why

Day 025 introduced `depends_on` but it only guaranteed that the `db` **container** had started — not that PostgreSQL inside it was accepting connections. PostgreSQL performs a one-time cluster initialisation (`initdb`) on its first boot, which takes several seconds. During that window the api container was already starting and attempting to open its connection pool, causing startup failures under cold conditions.

Docker's health check mechanism solves this precisely:

- Docker runs a configurable test command inside the container at a set interval.
- Until a test passes, the container reports `starting`.
- After a test exits 0, it becomes `healthy`.
- After `retries` consecutive failures, it becomes `unhealthy`.
- `condition: service_healthy` in `depends_on` tells Compose to block the api container until the db container is `healthy` — meaning Postgres has confirmed it is ready to serve connections.

### How

**Healthcheck block added to `db` in `compose.yaml`:**

```yaml
healthcheck:
  test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
  interval: 5s # run the probe every 5 s
  timeout: 5s # fail if probe takes longer than 5 s
  retries: 5 # declare unhealthy after 5 consecutive failures (~25 s)
  start_period: 10s # grace window; failures here don't count toward retries
```

**`depends_on` upgraded in `api`:**

```yaml
depends_on:
  db:
    condition: service_healthy # wait for db healthcheck to pass
```

**Docker health-check state machine:**

```
Container starts
      │
      ▼
  starting   ← grace period (start_period); failures don't count
      │
      ├── probe exits 0 ──────────────────────────────▶  healthy
      │
      └── probe fails 5× (after grace period) ─────▶  unhealthy
```

**Startup sequence (after Day 026):**

```
Compose
│
▼
db container starts
│
▼
PostgreSQL initializes (initdb on first boot)
│
▼
pg_isready probe passes → db status = healthy
│
▼
api container starts  ← Compose releases hold
│
▼
FastAPI opens connection pool → http://localhost:8000
```

**Inspect health metadata:**

```bash
docker inspect miniproject_student_management-db-1
```

The `Health` section in the output shows:

| Field           | Description                                            |
| --------------- | ------------------------------------------------------ |
| `Status`        | `starting` / `healthy` / `unhealthy`                   |
| `FailingStreak` | Number of consecutive failed probes                    |
| `Log`           | Last 5 probe results with exit code, output, timestamp |

### Where

```
compose.yaml       ← db service: healthcheck block added
                     api service: depends_on upgraded to condition: service_healthy
README.md          ← Docker Health Checks feature section added;
                     startup flow diagram added; docker compose ps output updated;
                     docker inspect reference added
version_history.md ← this v19 entry added
```

---

## v18 — Day 025: Docker Compose Orchestration

**When:** Day 025  
**Theme:** Multi-container orchestration — introduce `compose.yaml` to start the FastAPI app and a PostgreSQL container together with a single command; switch `DB_HOST` from `host.docker.internal` to the Compose service name `db`; load all secrets from `.env` so `compose.yaml` itself contains zero hard-coded credentials.

### What Changed

| Area                       |                                    Before (v17) | After (v18)                                                                                            |
| -------------------------- | ----------------------------------------------: | ------------------------------------------------------------------------------------------------------ |
| **`compose.yaml`**         |                          Empty placeholder file | Full Compose config: `api` service (built from Dockerfile) + `db` service (postgres:latest) + volume   |
| **Secrets management**     |             Secrets only managed for Docker run | `compose.yaml` uses `env_file: .env`; no credentials hard-coded in the Compose file                    |
| **DB_HOST**                | `host.docker.internal` (host-to-container path) | `db` (Compose service-name DNS — container-to-container path)                                          |
| **POSTGRES\_\* variables** |                           Not present in `.env` | `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` added; postgres container reads them on first init |
| **Volume**                 |                            No persistent volume | Named volume `postgres_data` persists DB data across `docker compose down` / `up` cycles               |
| **README**                 |    Mentioned `docker-compose.yml` as "optional" | Full Docker Compose section added: networking diagram, `env_file` explanation, all Compose commands    |
| **App Version**            |                                        `10.0.0` | `11.0.0`                                                                                               |

### Why

Docker Compose solves the remaining gap from Day 024: the FastAPI container could run but still required a Postgres database running on the host machine (`host.docker.internal`). This created an implicit external dependency that broke portability. With Compose:

- **Self-contained stack**: both services start together; no host Postgres installation needed.
- **Service-name DNS**: Docker's internal DNS resolver maps service names to container IPs automatically. Pointing `DB_HOST=db` is more robust than any host-based address.
- **Secret hygiene**: `env_file: .env` delegates all secret management to the `.env` file — the `compose.yaml` file is safe to commit with no sensitive values.
- **Data persistence**: without a named volume, `docker compose down` would destroy all database data on every cycle. The `postgres_data` volume survives container restarts.

### How

**New `compose.yaml`:**

```yaml
services:
  api:
    build: .
    ports:
      - "8000:8000"
    env_file:
      - .env
    depends_on:
      - db

  db:
    image: postgres:latest
    env_file:
      - .env
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

**Updated `.env`:**

```env
# FastAPI app connection (DB_HOST now points at the Compose service name)
DB_HOST=db

# Postgres container initialisation (first-startup only)
POSTGRES_DB=student_db
POSTGRES_USER=postgres
POSTGRES_PASSWORD=password@postgres
```

**Key Compose commands learned:**

```bash
docker compose up            # Start all services (foreground)
docker compose up -d         # Start all services (detached)
docker compose down          # Stop and remove containers (volume preserved)
docker compose ps            # List running services
docker compose logs api      # Tail logs from the api service
docker compose up --build    # Rebuild images and start
```

**Networking flow:**

```
FastAPI Container  (service: api)
│
│  DB_HOST=db   ←── set in .env
▼
Docker Internal DNS
│
▼
PostgreSQL Container  (service: db)
```

### Where

```
compose.yaml              ← written from scratch (was an empty placeholder)
.env                      ← DB_HOST changed from host.docker.internal → db;
                             POSTGRES_DB / POSTGRES_USER / POSTGRES_PASSWORD added
README.md                 ← Project structure updated; Docker Compose section rewritten
                             as Option B (Recommended); Tech Stack updated
version_history.md        ← this v18 entry added
```

---

## v17 — Day 024: Dockerization

**When:** Day 024  
**Theme:** Containerization — provide a reproducible, portable way to build and run the FastAPI app using Docker images and containers; document `Dockerfile`, `.dockerignore`, run/build commands, and host-to-container networking notes (host gateway / `host.docker.internal`).

### What Changed

| Area                       |                                        Before (v16) | After (v17)                                                                                                          |
| -------------------------- | --------------------------------------------------: | -------------------------------------------------------------------------------------------------------------------- |
| **Container packaging**    |                         No Docker artifacts in repo | Added `Dockerfile` and `.dockerignore`; documented `docker build` / `docker run` workflow                            |
| **Run instructions**       |                                `python app.py` only | Added containerized run instructions and guidance to pass `.env` via `--env-file`                                    |
| **Host DB connectivity**   | Documentation assumed host DB usage via `localhost` | Documented `DB_HOST=host.docker.internal` for host-to-container connectivity on Windows/macOS and Docker for Desktop |
| **Optional orchestration** |                                      Not documented | Recommended `docker-compose.yml` for app + postgres orchestration (example noted in README)                          |
| **App Version**            |                                             `9.0.0` | `10.0.0`                                                                                                             |

### Why

Packaging the application into a Docker image makes local testing and tutor verification reproducible regardless of the host Python environment. Key benefits:

- Reproducible builds: same image runs anywhere with Docker.
- Isolation: container provides consistent runtime environment (Python version, dependencies).
- Easier onboarding: tutors and CI systems can build/run the same image without installing Python packages locally.

Docker also exposes a common pitfall: when a containerized app needs to reach services running on the host (Postgres), `localhost` inside the container refers to the container itself. Documenting `host.docker.internal` prevents connection errors and speeds troubleshooting.

### How

Key artifacts and commands added to the repo:

- `Dockerfile` (example):

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

- `.dockerignore` (example): `.git`, `.venv`, `__pycache__`, `.env`, `.vscode`, etc.

- Build image:

```bash
docker build -t student-management-api .
```

- Run container (pass `.env`):

```bash
docker run --name student-api -p 8000:8000 --env-file .env student-management-api
```

- If your database runs on the host machine, set in `.env`:

```env
DB_HOST=host.docker.internal
```

- Optional: use `docker-compose.yml` to run app + postgres together (recommended for end-to-end local testing).

### Where

```
Dockerfile                ← added at project root
.dockerignore             ← added at project root
README.md                 ← updated: new Docker instructions + `--env-file` guidance
version_history.md        ← updated: this v17 entry
```

---

## v16 — Day 022: Database Indexing

**When:** Day 022  
**Theme:** Query performance — add B-Tree indexes on the most frequently searched columns so that common lookups become O(log N) point traversals instead of O(N) full-table scans

### What Changed

| Area                                    | Before (v15)                                               | After (v16)                                                                                                                         |
| --------------------------------------- | ---------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| **`email` column constraint**           | `VARCHAR(100)` — no uniqueness enforcement at the DB level | `VARCHAR(100) UNIQUE` — the DB rejects duplicate emails at INSERT time                                                              |
| **`idx_students_email` index**          | Not present                                                | `CREATE UNIQUE INDEX IF NOT EXISTS idx_students_email ON students (email)` — UNIQUE B-Tree; serves `WHERE email = %s` in O(log N)   |
| **`idx_students_name` index**           | Not present                                                | `CREATE INDEX IF NOT EXISTS idx_students_name ON students (name)` — non-unique B-Tree; accelerates prefix `ILIKE 'Alice%'` patterns |
| **`_create_table_if_not_exists()`**     | Created only the table                                     | Creates the table + both indexes in one idempotent method; safe to call on every startup                                            |
| **`get_student_by_email()` (ABC)**      | Not present                                                | Abstract method declared in `StudentRepository`; enforces the contract on every implementation                                      |
| **`get_student_by_email()` (Postgres)** | Not present                                                | Concrete implementation issues `WHERE email = %s`; resolved by `idx_students_email`                                                 |
| **Module docstrings**                   | Day 021 Update was the last entry                          | Day 022 Update added to `database_helper.py` and `student_repository.py`                                                            |
| **App Version**                         | `8.0.0`                                                    | `9.0.0`                                                                                                                             |

### Why

Without indexes, every `SELECT … WHERE email = %s` or `SELECT … WHERE name ILIKE …` query forces PostgreSQL to read **every row in the table** (a sequential scan). This is acceptable for a handful of students, but degrades quickly at scale:

| Table size     | Sequential scan (no index) | B-Tree index scan |
| -------------- | -------------------------- | ----------------- |
| 1,000 rows     | 1,000 row reads            | ~10 node visits   |
| 10,000 rows    | 10,000 row reads           | ~14 node visits   |
| 1,000,000 rows | 1,000,000 row reads        | ~20 node visits   |

Two specific columns benefit most:

1. **`email`** — the natural unique identifier for a student account. Used in authentication flows, duplicate-prevention checks on INSERT, and direct profile lookups. Because the query pattern is always an exact-match (`WHERE email = %s`), a UNIQUE B-Tree index is the ideal data structure. The UNIQUE property also enforces the data-integrity constraint that no two students can share an email address — at the **database level**, not just the application level.

2. **`name`** — the target of `search_students()`, which uses `ILIKE` pattern matching. A B-Tree index accelerates prefix patterns (`ILIKE 'Alice%'`) via an index range scan. Full-wildcard patterns (`ILIKE '%alice%'`) cannot use a B-Tree and still trigger a sequential scan; a future `pg_trgm` + GIN index would eliminate that remaining case.

### How

| Change                            | Where                                                   | Detail                                                                                                 |
| --------------------------------- | ------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `UNIQUE` constraint on `email`    | `_create_table_if_not_exists()` in `database_helper.py` | Added `UNIQUE` keyword to the `email` column definition in `CREATE TABLE IF NOT EXISTS`                |
| `idx_students_email`              | `_create_table_if_not_exists()` in `database_helper.py` | `CREATE UNIQUE INDEX IF NOT EXISTS idx_students_email ON students (email)` — runs after table creation |
| `idx_students_name`               | `_create_table_if_not_exists()` in `database_helper.py` | `CREATE INDEX IF NOT EXISTS idx_students_name ON students (name)` — runs after table creation          |
| `get_student_by_email()` abstract | `StudentRepository` ABC in `student_repository.py`      | New `@abstractmethod` — all future implementations must provide this method                            |
| `get_student_by_email()` concrete | `PostgresStudentRepository` in `student_repository.py`  | `fetch_one("SELECT * FROM students WHERE email = %s", (email,))` — exercises the UNIQUE index          |

### Key Concept: Why UNIQUE Index Over UNIQUE Constraint?

PostgreSQL implements a `UNIQUE` column constraint **by creating an implicit B-Tree index** internally. Declaring the index explicitly with `CREATE UNIQUE INDEX` makes the index name known and queryable:

```sql
-- Verify the index exists and is in use:
SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'students';

-- Confirm the query planner uses it (expect "Index Scan using idx_students_email"):
EXPLAIN ANALYZE SELECT * FROM students WHERE email = 'alice@example.com';
```

Using `IF NOT EXISTS` on both `CREATE TABLE` and `CREATE INDEX` makes `_create_table_if_not_exists()` fully **idempotent** — it can be called on every application startup with no errors and no duplicate index creation.

### Where

```
database/
  database_helper.py     ← _create_table_if_not_exists(): table now has UNIQUE on email;
                            CREATE UNIQUE INDEX IF NOT EXISTS idx_students_email added
                            CREATE INDEX IF NOT EXISTS idx_students_name added
                            Day 022 Update note added to module docstring

repositories/
  student_repository.py  ← StudentRepository (ABC): get_student_by_email() abstract method added
                            PostgresStudentRepository: get_student_by_email() implementation added
                            Day 022 Update note added to module docstring
```

---

## v15 — Day 021: Connection Pooling and Lifespan Control

**When:** Day 021  
**Theme:** Concurrency readiness — replace the single persistent connection with a managed connection pool; every query borrows a connection for exactly one operation and returns it immediately

### What Changed

| Area                    | Before (v14)                                                                                                    | After (v15)                                                                                           |
| ----------------------- | --------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| **Connection model**    | `self.connection` — one `psycopg.Connection` per `DatabaseHelper` instance, held for the whole process lifetime | `self._pool` — `psycopg_pool.ConnectionPool`; shared pool of up to `DB_POOL_MAX_SIZE` connections     |
| **Startup**             | `db_helper.connect()` — opens one connection, runs schema check                                                 | `db_helper.open_pool()` — creates `min_size` connections; runs schema check via a borrowed connection |
| **Shutdown**            | `db_helper.close()` — closes the one connection                                                                 | `db_helper.close_pool()` — drains & closes all pool connections                                       |
| **Per-query lifecycle** | Connection held from startup to shutdown; queries share it sequentially                                         | Connection borrowed at start of each `execute_*` / `fetch_*` call; returned immediately after         |
| **Concurrency**         | Only 1 query at a time (single connection = no parallelism)                                                     | Up to `DB_POOL_MAX_SIZE` queries simultaneously                                                       |
| **Config**              | Not configurable                                                                                                | `DB_POOL_MIN_SIZE` / `DB_POOL_MAX_SIZE` in `.env` → `settings.db_pool_min_size / max_size`            |
| **Legacy aliases**      | `connect()` / `close()` were the only lifecycle methods                                                         | `open_pool()` / `close_pool()` are new canonical names; `connect()` / `close()` now delegate to them  |
| **App Version**         | `7.0.0`                                                                                                         | `8.0.0`                                                                                               |

### Why

A single persistent connection is a development convenience, not a production-ready pattern:

1. **No parallelism**: If 10 requests arrive simultaneously, 9 of them queue behind the one connection. Response time degrades linearly with concurrency.
2. **Single point of failure**: If that one connection drops (network blip, PostgreSQL restart), the whole application loses database access until the process is restarted.
3. **Hidden resource leak on errors**: psycopg3 leaves a connection in an aborted-transaction state after any query failure. With a pool, the bad connection is automatically recycled and replaced.

`psycopg_pool.ConnectionPool` addresses all three:

- Keeps `min_size` connections pre-warmed (no cold-start latency for the first N concurrent requests).
- Allows up to `max_size` concurrent DB queries; requests beyond that wait in an internal queue (bounded wait, not indefinite blocking).
- Automatically replaces stale or dead connections; surviving connections keep serving.
- Each query borrows a connection for its lifetime only — the pool reclaims it the moment the query finishes.

### How (Three Exercises)

| Exercise         | What                                | Implementation                                                                                                                                                                        |
| ---------------- | ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Day 021 Ex 3** | Replace single connection with pool | `DatabaseHelper`: `self._pool = ConnectionPool(conninfo=..., min_size=..., max_size=..., open=True)`; all `execute_*` / `fetch_*` methods use `with self._pool.connection() as conn:` |
| **Day 021 Ex 4** | FastAPI Lifespan with pool          | `main.py` lifespan: STARTUP calls `db_helper.open_pool()`; SHUTDOWN calls `db_helper.close_pool()`; startup log reports `min` / `max` pool size                                       |
| **Day 021 Ex 5** | Request-flow trace                  | `day_21_practice.md` — full `Client → Router → Service → Repository → Pool → Database` trace with exact connection acquire/release points                                             |

### Key Concept: Borrow-per-Operation Pattern

```python
# Every execute_* method inside DatabaseHelper now looks like this:
def execute_write(self, query, params=None):
    with self._pool.connection() as conn:   # ← CONNECTION ACQUIRED here
        with conn.transaction():            # ← BEGIN
            with conn.cursor() as cur:
                cur.execute(query, params)
                                            # ← COMMIT on clean exit
                                            # ← ROLLBACK on exception
    # ← CONNECTION RETURNED TO POOL here (automatically)
```

The connection is held for **zero time** outside of actual SQL execution. This is what makes the pool effective under concurrent load — connections are never "idle-held" by a request that is doing computation, validation, or JSON serialization.

### Where

```
config.py                ← Added: db_pool_min_size (int=1), db_pool_max_size (int=5)
.env                     ← Added: DB_POOL_MIN_SIZE=1, DB_POOL_MAX_SIZE=5; APP_VERSION→8.0.0
.env.example             ← (should be updated to match .env template)

database/
  database_helper.py     ← REWRITTEN: self.connection → self._pool (ConnectionPool)
                            open_pool() / close_pool() — new lifecycle methods
                            execute_query(), execute_write(), execute_write_transaction(),
                            fetch_all(), fetch_one() — all now use with self._pool.connection()
                            connect() / close() — kept as legacy aliases

main.py                  ← Updated lifespan: open_pool() on startup, close_pool() on shutdown
                            Startup log now includes pool min/max sizes

day_21_practice.md       ← NEW: Exercise 5 answer — full request flow trace with acquire/release points
```

---

## v14 — Day 020: Database Transactions and ACID

**When:** Day 020  
**Theme:** Data integrity — wrap all write operations in explicit ACID transactions so the database is never left in a partial or dirty state

### What Changed

| Area                                    | Before (v13)                                                                                                                              | After (v14)                                                                                                                           |
| --------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| **`execute_query()` failure path**      | Logs and re-raises; connection left in aborted state                                                                                      | Now calls `connection.rollback()` before re-raising; connection is always clean for next query                                        |
| **`execute_write()` (new)**             | Not present                                                                                                                               | Wraps a single INSERT/UPDATE/DELETE in `connection.transaction()` — automatic COMMIT on success, ROLLBACK on failure                  |
| **`execute_write_transaction()` (new)** | Not present                                                                                                                               | Accepts a callable `steps(cursor)` and runs it inside one `connection.transaction()` — entire multi-step operation is one atomic unit |
| **`add_student` in repository**         | Two separate calls: `fetch_one()` (SELECT max id) then `execute_query()` (INSERT) with `commit=True` — race condition window between them | Single `execute_write_transaction()` call; SELECT and INSERT share one cursor inside one transaction                                  |
| **`delete_student` in repository**      | `execute_query(..., commit=True)` — commit but no rollback on failure                                                                     | `execute_write()` — explicit transaction with automatic rollback on any error                                                         |
| **App Version**                         | `6.0.0`                                                                                                                                   | `7.0.0`                                                                                                                               |

### Why

The previous write pattern had two concrete problems:

1. **Dirty connection state after failure**: psycopg3 operates in autocommit=False mode by default. When a query fails, the connection enters an aborted transaction state. Any subsequent query on the same connection raises `InFailedSqlTransaction` — effectively rendering the connection unusable — until `rollback()` is called explicitly. This was never called.

2. **Race condition in `add_student`**: The ID-generation `SELECT COALESCE(MAX(id),0)+1` and the `INSERT` were two separate round-trips to the database. Under concurrent load (e.g. two simultaneous POST `/students/` requests), both could read the same max ID, then both attempt to INSERT with that same primary key — the second would fail with a unique-constraint violation.

### How

| Change                         | Where                            | Detail                                                                                                     |
| ------------------------------ | -------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| Rollback on query failure      | `DatabaseHelper.execute_query()` | Added `try: self.connection.rollback()` in the `except` block before re-raising                            |
| `execute_write()`              | `DatabaseHelper`                 | Uses `with self.connection.transaction():` context manager; single cursor executes the write               |
| `execute_write_transaction()`  | `DatabaseHelper`                 | Uses `with self.connection.transaction():` + `with cursor:` then calls `steps(cur)` and returns its result |
| `add_student` atomic           | `PostgresStudentRepository`      | Defined `_create(cur)` inner function with SELECT + INSERT; passed to `execute_write_transaction()`        |
| `delete_student` transactional | `PostgresStudentRepository`      | Replaced `execute_query(..., commit=True)` with `execute_write(DELETE_SQL, params)`                        |

### Key Concept: psycopg Transaction Context Manager

```python
with self.connection.transaction():   # issues BEGIN
    with self.connection.cursor() as cur:
        cur.execute(...)              # all statements here are in the same transaction
# issues COMMIT if no exception, ROLLBACK if exception raised
```

This is the psycopg3 idiomatic way to manage transactions. The `connection.transaction()` context manager:

- Issues `BEGIN` on `__enter__`
- Issues `COMMIT` on clean `__exit__`
- Issues `ROLLBACK` on `__exit__` with an exception — no explicit cleanup needed

### Where

```
database/
  database_helper.py     ← execute_query: added rollback in except block
                            execute_write: NEW — single write in one transaction
                            execute_write_transaction: NEW — multi-step callable transaction

repositories/
  student_repository.py  ← add_student: SELECT+INSERT now one atomic transaction via execute_write_transaction()
                            delete_student: DELETE now uses execute_write() instead of execute_query(commit=True)
```

---

## v13 — Day 019: Configuration & Environment Variables

**When:** Day 019  
**Theme:** Deployment readiness — eliminate all hardcoded secrets and settings; load everything from `.env` via a typed Pydantic Settings module

### What Changed

| Area                     | Before (v12)                                                         | After (v13)                                                                        |
| ------------------------ | -------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| **Config Module**        | Not present                                                          | `config.py` — `Settings(BaseSettings)` class; reads `.env` via `pydantic-settings` |
| **Environment File**     | Not present (empty stub)                                             | `.env` — all settings: app metadata, JWT secret, DB credentials, log level         |
| **Environment Template** | Not present                                                          | `.env.example` — safe, committable template with placeholder values                |
| **JWT Secret**           | Hardcoded `"day015-super-secret-key-..."` in `jwt_utils.py`          | `settings.jwt_secret_key` read from `JWT_SECRET_KEY` in `.env`                     |
| **JWT Algorithm**        | Hardcoded `"HS256"` in `jwt_utils.py`                                | `settings.jwt_algorithm` from `JWT_ALGORITHM` in `.env`                            |
| **JWT Expiry**           | Hardcoded `30` in `jwt_utils.py`                                     | `settings.jwt_access_token_expire_minutes` from `.env`                             |
| **DB Connection**        | `os.getenv("DB_HOST", ...)` etc. scattered in `database_helper.py`   | `settings.db_host / db_name / db_user / db_password / db_port`                     |
| **Log Level (console)**  | Hardcoded `logging.INFO` in `logger_config.py`                       | `settings.log_level_int` from `LOG_LEVEL` in `.env`                                |
| **App Name / Version**   | Hardcoded strings `"Student Management..."` / `"5.0.0"` in `main.py` | `settings.app_name` / `settings.app_version` from `.env`                           |
| **Startup Log**          | Simple `"routers and middleware registered"` message                 | Config profile logged: name, version, debug flag, log level                        |
| **App Version**          | `5.0.0`                                                              | `6.0.0`                                                                            |

### Why

Hardcoded secrets and settings are the single biggest security risk in application development:

- A hardcoded `SECRET_KEY` in source code is exposed to anyone who can read the repository.
- Changing a DB password or JWT secret requires modifying source code and redeploying.
- There is no way to have different settings for dev, staging, and production without code changes.

A `.env` + config module pattern solves all three:

- **Secrets stay out of code**: `.env` is added to `.gitignore`; `.env.example` is the safe template.
- **Config changes without code changes**: swap a DB URL or secret key by editing `.env` only.
- **Type safety**: Pydantic validates every setting at startup; bad values cause a clear error immediately.

### How (Six Exercises)

| Exercise         | What                                      | Implementation                                                                                                                                                                        |
| ---------------- | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Day 019 Ex 1** | Create `.env` file                        | `.env` — stores `APP_NAME`, `APP_VERSION`, `DEBUG`, `JWT_SECRET_KEY`, `JWT_ALGORITHM`, `JWT_ACCESS_TOKEN_EXPIRE_MINUTES`, `DB_*`, `LOG_LEVEL`                                         |
| **Day 019 Ex 2** | Create `config.py` with Pydantic Settings | `Settings(BaseSettings)` class with typed fields; `model_config` sets `env_file=".env"`; `log_level_int` property converts string to `logging` int; `settings = Settings()` singleton |
| **Day 019 Ex 3** | Read config in `main.py`                  | `FastAPI(title=settings.app_name, version=settings.app_version)`; startup log prints active config profile                                                                            |
| **Day 019 Ex 4** | Move JWT secret to config                 | `jwt_utils.py`: removed hardcoded `SECRET_KEY`; now reads `settings.jwt_secret_key`, `settings.jwt_algorithm`, `settings.jwt_access_token_expire_minutes`                             |
| **Day 019 Ex 5** | Move DB URL to config                     | `database_helper.py`: removed all `os.getenv()` calls; now reads `settings.db_host / db_name / db_user / db_password / db_port`                                                       |
| **Day 019 Ex 6** | Configure logging level                   | `logger_config.py`: `StreamHandler.setLevel(settings.log_level_int)` — set `LOG_LEVEL=DEBUG` in `.env` to expose debug traces on console                                              |

### Key Concept: Settings Priority

Pydantic Settings reads values in this priority order (highest → lowest):

```text
1. Process environment variables (os.environ)   ← set by CI/CD, Docker, systemd
2. .env file in the working directory            ← local development
3. Default values declared in Settings class     ← last-resort fallback
```

This means you can override `.env` values in production by setting real environment variables without changing the file.

### Where

```
config.py            ← NEW: Settings(BaseSettings) class + settings singleton
.env                 ← NEW: real configuration values (add to .gitignore)
.env.example         ← NEW: safe template (commit this to version control)

auth/jwt_utils.py    ← Updated: hardcoded SECRET_KEY replaced by settings.jwt_secret_key
database/
  database_helper.py ← Updated: os.getenv() calls replaced by settings.db_* attributes
logger_config.py     ← Updated: stream_handler.setLevel(settings.log_level_int)
main.py              ← Updated: FastAPI title/version from settings; config startup log
```

---

## v12 — Day 018: Global Exception Handling

**When:** Day 018  
**Theme:** Reliability — replace ad-hoc HTTPException raises and None-checks with a clean custom-exception + global-handler pattern

### What Changed

| Area | Before (v11) | After (v12) |
|---|---|---|\n| **Custom Exception** | Not present | `exceptions/student_exceptions.py` — `StudentNotFoundException(student_id)` |
| **Exceptions Package** | Not present | `exceptions/__init__.py` — re-exports `StudentNotFoundException` for clean imports |
| **Service: get_student_by_id** | Returns `None` when student not found | Raises `StudentNotFoundException` — no more nullable return type |
| **Service: delete_student** | Returns `bool` (False when not found) | Raises `StudentNotFoundException` — no more boolean flag |
| **Router: get / delete** | Manual `if student is None` / `if not deleted` → raises `HTTPException` | Removed — exception propagates automatically to global handler |
| **Global Handler: 404** | Not present | `@app.exception_handler(StudentNotFoundException)` → `{error, message, student_id}` JSON |
| **Global Handler: 500** | Not present | `@app.exception_handler(Exception)` catch-all → `{error, message, exception_type}` JSON |
| **Exception Logging** | Not applicable | All handlers log via centralized logger (`WARNING` for 404, `EXCEPTION` for 500) |
| **App Version** | `4.0.0` | `5.0.0` |

### Why

Without a consistent exception strategy:

- Routers accumulate boilerplate `if result is None: raise HTTPException(...)` in every handler.
- The client receives either a vague `500 Internal Server Error` HTML page or inconsistent JSON shapes across endpoints.
- Service layer was returning nullable types (`None` / `bool`) that pushed error-handling responsibility to the wrong layer.

A custom exception + global handler separates concerns properly:

- The **service layer** detects the error and raises the right domain exception.
- The **global handler** in `main.py` decides the HTTP status code and JSON response shape — once, for the whole app.
- The **router** stays completely clean — it just calls the service and returns the result.

### How (Five Exercises)

| Exercise         | What                                          | Implementation                                                                                                                                                                 |
| ---------------- | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Day 018 Ex 1** | Raise `HTTPException` for a missing student   | Moved to service layer: `get_student_by_id` and `delete_student` raise `StudentNotFoundException` instead of returning `None`/`False`; router no longer raises `HTTPException` |
| **Day 018 Ex 2** | Create `StudentNotFoundException`             | `exceptions/student_exceptions.py` — subclasses `Exception`, stores `student_id` as an attribute, sets a human-readable message via `super().__init__()`                       |
| **Day 018 Ex 3** | Global handler for `StudentNotFoundException` | `@app.exception_handler(StudentNotFoundException)` in `main.py` — returns `HTTP 404` with `{error, message, student_id}`                                                       |
| **Day 018 Ex 4** | Log the exception                             | All handlers call `logger.warning()` (client errors) or `logger.exception()` (server errors) via the existing `logger_config` infrastructure; no `print()` used                |
| **Day 018 Ex 5** | Trigger scenarios via Swagger                 | GET/DELETE with a non-existent ID → 404 JSON; POST with empty name → 400 JSON; terminal shows WARNING; `logs/application.log` shows full structured entry                      |

### Key Concept: Exception Handler Precedence

FastAPI evaluates exception handlers from **most-specific to least-specific**:

```text
@app.exception_handler(StudentNotFoundException)  ← checked first for StudentNotFoundException
@app.exception_handler(ValueError)               ← checked first for ValueError
@app.exception_handler(Exception)                ← catch-all fallback (last resort)
```

This means the catch-all `Exception` handler never silently swallows errors that already have a dedicated handler — each exception type gets the right response shape.

### Where

```
exceptions/
├── __init__.py              ← NEW: re-exports StudentNotFoundException
└── student_exceptions.py   ← NEW: StudentNotFoundException(student_id) class

main.py                      ← Added: student_not_found_exception_handler, unhandled_exception_handler
                                Updated: app version 4.0.0 → 5.0.0; comment labels updated to Day 017 Exn
services/student_service.py  ← Updated: get_student_by_id raises StudentNotFoundException (not return None)
                                         delete_student raises StudentNotFoundException (not return False)
routers/students.py          ← Updated: removed manual None/bool checks; HTTPException import removed
```

---

## v11 — Day 017: Python Logging Practice

**When:** Day 017  
**Theme:** Observability — structured logging with FileHandler, StreamHandler, and Formatter across all application layers

### What Changed

| Area                  | Before (v10)                                                   | After (v11)                                                                                                                    |
| --------------------- | -------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| **Logging**           | `print()` statements scattered across `main.py`, `middleware/` | Centralized `logging` module with `Logger`, `FileHandler`, `StreamHandler`, `Formatter`                                        |
| **Log Config**        | Not present                                                    | `logger_config.py` — single module wires the entire logging pipeline                                                           |
| **Log File**          | Not present                                                    | `logs/application.log` — all `DEBUG`+ records written here persistently                                                        |
| **Console Output**    | Raw `print()` text                                             | Structured `INFO`+ records with timestamp, level, module, and message                                                          |
| **Exception Logging** | No stack traces captured                                       | `logger.exception()` inside every `try/except` captures full Python stack traces                                               |
| **Log Levels**        | None (print = always visible)                                  | `DEBUG` (file-only trace), `INFO` (operations), `WARNING` (missing resources, auth fails), `ERROR`/`EXCEPTION` (server errors) |
| **Middleware**        | `print()` in every middleware class                            | `logger.info()` for requests; `logger.debug()` for timing & LIFO demo; `logger.warning/error()` for 4xx/5xx                    |
| **Repository**        | No observability                                               | `logger.info()` on CRUD success; `logger.warning()` for not-found; `logger.exception()` on DB failure                          |
| **Service**           | No observability                                               | `logger.info()` for method entry/exit; `logger.warning()` for validation failures and not-found                                |
| **Router**            | No observability                                               | `logger.info()` for route entry/result; `logger.warning()` before 404 raises                                                   |
| **Auth Router**       | No observability                                               | `logger.info()` for login success; `logger.warning()` for wrong credentials; `logger.debug()` for token ops                    |
| **JWT Bearer**        | No observability                                               | `logger.warning()` on validation failure; `logger.debug()` on success                                                          |
| **DB Helper**         | No observability                                               | `logger.info()` for connect/close; `logger.debug()` for query traces; `logger.exception()` on failure                          |
| **App Version**       | `3.0.0`                                                        | `4.0.0`                                                                                                                        |

### Why

Application logs are the primary tool for diagnosing production issues. Without structured logging:

- There is no persistent record of what happened when an error occurs.
- `print()` has no severity level — you can't distinguish a debug trace from a critical failure.
- Stack traces disappear after the terminal session ends.

Python's `logging` module solves all three problems: it supports severity levels, persistent file output, consistent formatting, and automatic stack trace capture via `logger.exception()`.

### How (Five Exercises)

| Exercise | What                                 | Implementation                                                                                                                           |
| -------- | ------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------- |
| **Ex 1** | Configure logging                    | `logging.Logger` + manual `FileHandler` + `StreamHandler` + `Formatter` in `logger_config.py` (replaces `basicConfig` for finer control) |
| **Ex 2** | Write logs to `logs/application.log` | `FileHandler(LOG_FILE, mode="a")` at `DEBUG` level — captures everything including trace details invisible on console                    |
| **Ex 3** | Replace `print()` with logger calls  | Every module: `logger.info()` for normal ops, `logger.warning()` for user/auth errors, `logger.error()` for server errors                |
| **Ex 4** | Log exceptions                       | `logger.exception("...")` inside every `try/except` — automatically appends the full traceback to the log file                           |
| **Ex 5** | Review output                        | Console shows `INFO`+ only; `logs/application.log` shows everything including `DEBUG` traces and stack traces                            |

### Key Concept: Logger Hierarchy

All loggers use the naming convention `student_management.<module>`:

```text
student_management                   ← root app logger (configured in logger_config.py)
├── student_management.main
├── student_management.middleware.request_middleware
├── student_management.routers.students
├── student_management.routers.auth
├── student_management.services.student_service
├── student_management.repositories.student_repository
├── student_management.database.database_helper
└── student_management.auth.jwt_bearer
```

Child loggers inherit both handlers from the parent. Calling `get_logger(__name__)` in each module automatically produces the correct name.

### Log Level Strategy

| Level       | When Used                                                        | Visible        |
| ----------- | ---------------------------------------------------------------- | -------------- |
| `DEBUG`     | Query traces, LIFO demo steps, token validation success          | File only      |
| `INFO`      | Startup, shutdown, CRUD success, request/response summary        | Console + File |
| `WARNING`   | Record not found, auth failures, validation errors (user errors) | Console + File |
| `ERROR`     | 5xx response status codes                                        | Console + File |
| `EXCEPTION` | Any `except` block — wraps ERROR with full stack trace           | Console + File |

### Where

```
logger_config.py                ← NEW: root logger, FileHandler, StreamHandler, Formatter, get_logger()
logs/
└── application.log             ← AUTO-CREATED: persistent log output (DEBUG+)

main.py                         ← lifespan startup/shutdown now uses logger; exception on DB fail
middleware/request_middleware.py ← all print() replaced; level varies by HTTP status
database/database_helper.py     ← connect/close/execute all logged; try/except with logger.exception()
repositories/student_repository.py ← full CRUD observability; logger.exception() on every failure
services/student_service.py     ← method entry/exit logged; warning on validation errors
routers/students.py             ← route entry/result logged; warning before 404
routers/auth.py                 ← login attempts/failures logged; profile access logged
auth/jwt_bearer.py              ← JWT validation success/failure logged
```

---

## v10 — Day 016: Middleware Practice

**When:** Day 016  
**Theme:** HTTP Middleware layer — request pipeline observability and cross-cutting concerns

### What Changed

| Area                | Before (v9) | After (v10)                                                                            |
| ------------------- | ----------- | -------------------------------------------------------------------------------------- |
| **Middleware**      | None        | Five middleware registered via `add_middleware()` in `main.py`                         |
| **Request Logging** | Not present | `LogIncomingRequestMiddleware` — prints `METHOD /path` on every request                |
| **Execution Time**  | Not present | `ExecutionTimeMiddleware` — prints duration & adds `X-Process-Time-Ms` response header |
| **Console Logging** | Not present | `ConsoleRequestLogMiddleware` — prints `METHOD /path -> STATUS` after each request     |
| **CORS**            | Not enabled | `CORSMiddleware` — allows origin `http://localhost:5173`, all methods & headers        |
| **Order Demo**      | Not present | `MiddlewareOrderDemoA` & `MiddlewareOrderDemoB` — illustrates LIFO middleware pipeline |
| **New Module**      | Not present | `middleware/` package: `__init__.py` + `request_middleware.py`                         |
| **App Version**     | `2.0.0`     | `3.0.0`                                                                                |

### Why

Middleware is how real-world APIs handle **cross-cutting concerns** — things that apply to every request without polluting individual route handlers. Logging, timing, CORS, and auth checks all belong in the middleware pipeline, not inside route functions.

### How (Five Exercises)

| Exercise | Class                                           | Mechanism                                                                           |
| -------- | ----------------------------------------------- | ----------------------------------------------------------------------------------- |
| **Ex 1** | `LogIncomingRequestMiddleware`                  | `BaseHTTPMiddleware` subclass; prints before `call_next()`                          |
| **Ex 2** | `ExecutionTimeMiddleware`                       | Records `time.time()` before/after `call_next()`; writes `X-Process-Time-Ms` header |
| **Ex 3** | `ConsoleRequestLogMiddleware`                   | Calls `call_next()`, then prints `response.status_code`                             |
| **Ex 4** | `CORSMiddleware`                                | FastAPI built-in; configured with `allow_origins=["http://localhost:5173"]`         |
| **Ex 5** | `MiddlewareOrderDemoA` + `MiddlewareOrderDemoB` | Both print on request entry and response exit to show LIFO order                    |

### Key Concept: LIFO Middleware Stack

FastAPI middleware is a **Last In, First Out** stack. The _last_ `add_middleware()` call runs _first_ on the incoming request, then response unwinding happens in reverse.

```text
Registration order in main.py → Runtime execution order (request)
──────────────────────────────────────────────────────────────────
1. CORSMiddleware          (added first)  →  runs last on request
2. MiddlewareOrderDemoA                  →  runs 5th on request
3. MiddlewareOrderDemoB                  →  runs 4th on request
4. LogIncomingRequestMiddleware          →  runs 3rd on request
5. ExecutionTimeMiddleware               →  runs 2nd on request
6. ConsoleRequestLogMiddleware (last)    →  runs 1st on request
```

### Where

```
middleware/
├── __init__.py
└── request_middleware.py   ← all five middleware classes
main.py                     ← add_middleware() registration block
```

---

## v9 — Day 015: JWT Authentication

**When:** Day 015  
**Theme:** Security — password hashing, JWT issuance, protected endpoints

### What Changed

| Area                   | Before (v8)               | After (v9)                                                                          |
| ---------------------- | ------------------------- | ----------------------------------------------------------------------------------- |
| **Authentication**     | None — all endpoints open | JWT Bearer authentication added                                                     |
| **Password Hashing**   | Not present               | `passlib` + `bcrypt` via `hash_password()` / `verify_password()`                    |
| **Token Generation**   | Not present               | `python-jose` HS256 signed JWTs with `sub`, `role`, `exp`, `iat` claims             |
| **Token Decoding**     | Not present               | `decode_token()` verifies signature + expiry; `inspect_token_parts()` for education |
| **Protected Endpoint** | Not present               | `GET /auth/profile` — requires valid `Authorization: Bearer <token>` header         |
| **Auth Dependency**    | Not present               | `get_current_user` FastAPI dependency; `OAuth2PasswordBearer` wires Swagger padlock |
| **Login Endpoint**     | Not present               | `POST /auth/login` — accepts `OAuth2PasswordRequestForm`; returns `TokenResponse`   |
| **Demo Endpoints**     | Not present               | `GET /auth/demo/hash`, `GET /auth/demo/token`, `POST /auth/inspect-token`           |
| **New Module**         | Not present               | `auth/` package: `password_utils.py`, `jwt_utils.py`, `jwt_bearer.py`               |
| **New Router**         | Not present               | `routers/auth.py` registered as `auth_router` in `main.py`                          |
| **App Version**        | `1.0.0`                   | `2.0.0`                                                                             |

### Why

All API endpoints were completely open — anyone could create or delete students. Real systems need authentication. JWT (JSON Web Token) is the industry-standard stateless auth mechanism for REST APIs; it doesn't require server-side session storage, scales horizontally, and self-describes the user's identity and role.

bcrypt is used for password hashing because it is intentionally slow (work-factor based), making brute-force attacks computationally expensive.

### How

**Authentication Flow (OAuth2 Bearer pattern):**

1. **Login** — Client POSTs `username` + `password` (form data) to `POST /auth/login`. Server verifies the bcrypt hash with `verify_password()`, then mints a signed JWT using `create_access_token()`.
2. **Token** — The JWT contains `sub` (username), `role`, `exp` (30-min expiry), and `iat` claims, signed with HS256. The client stores this token.
3. **Protected Request** — Client sends `Authorization: Bearer <token>` header. The `get_current_user` dependency (via `OAuth2PasswordBearer`) extracts the token, calls `decode_token()` to verify the signature and expiry, and injects the payload into the route handler.
4. **Rejection** — Any missing, tampered, or expired token returns `HTTP 401 Unauthorized` before the route function even runs.

**Five Exercises:**

| Exercise   | Endpoint                   | What it demonstrates                                      |
| ---------- | -------------------------- | --------------------------------------------------------- |
| **Ex 1**   | `GET /auth/demo/hash`      | bcrypt hashing + salt proof + `verify_password()`         |
| **Ex 1+2** | `POST /auth/login`         | Credential check + JWT issuance                           |
| **Ex 2+3** | `GET /auth/demo/token`     | JWT generation + structural inspection                    |
| **Ex 3**   | `POST /auth/inspect-token` | Decode any JWT Header/Payload/Signature (no verification) |
| **Ex 4+5** | `GET /auth/profile`        | Protected endpoint + Swagger Bearer auth testing          |

### Where

```
auth/
├── __init__.py
├── password_utils.py   ← hash_password(), verify_password() via passlib/bcrypt
├── jwt_utils.py        ← create_access_token(), decode_token(), inspect_token_parts()
└── jwt_bearer.py       ← get_current_user FastAPI dependency + OAuth2PasswordBearer

routers/
└── auth.py             ← all auth endpoints (login, demo/hash, demo/token, inspect-token, profile)

main.py                 ← app.include_router(auth_router)
```

**Demo credentials:** `admin/admin123` · `alice/student456` · `bob/teacher789`

---

## v8 — Day 014: Split Models & Email Validation

**When:** Day 014  
**Theme:** Pydantic model discipline — separate request and response schemas + email field

### What Changed

| Area                      | Before (v7)                                                  | After (v8)                                                                           |
| ------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| **Student Fields**        | `id`, `name`, `age`, `city`                                  | `id`, `name`, `age`, `city`, **`email`**                                             |
| **Pydantic Model**        | Single `Student` class (request + response combined)         | Split into `Student_model` (request) and `Student_response_model` (response)         |
| **Request `id` field**    | `id: int \| None = None` (optional, could be sent by client) | Removed from `Student_model` — client never sends an `id`                            |
| **Response `id` field**   | `id: int \| None` (could be `None`)                          | `id: int` (required; guaranteed by DB before response is sent)                       |
| **Field Validation**      | No constraints on `name`, `age`, `city`                      | `Field(min_length=1, max_length=100)` on `name`, `city`; `Field(ge=0)` on `age`      |
| **Email Validation**      | Not present                                                  | `email: EmailStr` with Pydantic `EmailStr` type (requires `pydantic[email]`)         |
| **Database Table**        | `id`, `name`, `age`, `city` columns                          | Added `email VARCHAR(100)` column                                                    |
| **SQL Queries**           | `INSERT ... VALUES (%s, %s, %s, %s)`                         | `INSERT ... VALUES (%s, %s, %s, %s, %s)` (includes `email`)                          |
| **Repository signatures** | Used `Student` for both input and output                     | `add_student` accepts `Student_model`; all return types use `Student_response_model` |
| **Service signatures**    | `add_student(name, age, city)`                               | `add_student(name, age, city, email)`                                                |
| **Router signatures**     | Used `Student` for request/response models                   | Uses `Student_model` for request body, `Student_response_model` for response         |

### Why

Using one model for both request and response is a bad practice. It leaks server-generated fields (like `id`) into the request contract and makes the API surface ambiguous. Splitting into `Student_model` (what the client sends) and `Student_response_model` (what the server returns) enforces proper boundaries and makes validation intent explicit.

`EmailStr` was added to demonstrate Pydantic's specialised type validators beyond simple `str`.

### How

- `Student_model` — request body: `name`, `age`, `city`, `email` (no `id`; id is DB-generated)
- `Student_response_model` — response body: `id: int`, `name`, `age`, `city`, `email` (id is guaranteed non-None because it's read from the DB after INSERT)
- `Field(...)` constraints added at model layer so Pydantic rejects invalid data before it even reaches the service

### Where

```
models/student.py       ← Student_model + Student_response_model defined here
routers/students.py     ← request body type changed to Student_model; response_model changed to Student_response_model
services/student_service.py  ← add_student() signature updated to include email
repositories/student_repository.py  ← SQL INSERT updated; all return types use Student_response_model
database/database_helper.py  ← no change (executes whatever SQL is passed)
```

> **DB migration note:** If upgrading from v7, run:
>
> ```sql
> ALTER TABLE students ADD COLUMN IF NOT EXISTS email VARCHAR(100);
> ```

---

## v7 — Day 013: FastAPI REST API Migration

**When:** Day 013  
**Theme:** CLI → REST API; introduced Repository Pattern, Dependency Injection, and Clean Architecture

### What Changed

| Area                  | Before (v6)                 | After (v7)                                          |
| --------------------- | --------------------------- | --------------------------------------------------- |
| **Interface**         | CLI (terminal menu)         | REST API (HTTP endpoints via FastAPI)               |
| **Entry Point**       | `main.py` (CLI loop)        | `main.py` (FastAPI app) + `app.py` (Uvicorn runner) |
| **Student Model**     | `id`, `name`                | `id`, `name`, `age`, `city`                         |
| **Database Table**    | `id`, `name` only           | `id`, `name`, `age`, `city`                         |
| **Dependency Wiring** | Manual instantiation        | FastAPI `Depends()` injection chain                 |
| **Error Handling**    | `print()` / bare exceptions | Global `ValueError` → HTTP 400 handler              |
| **App Lifecycle**     | No lifecycle management     | `@asynccontextmanager` lifespan (startup/shutdown)  |
| **Search**            | Basic string scan           | Case-insensitive PostgreSQL `ILIKE` query           |
| **API Docs**          | None                        | Auto-generated Swagger UI at `/docs`                |

### Why

The CLI interface was a learning exercise. REST APIs are the real-world standard for backend services. FastAPI was chosen because it provides automatic schema validation (via Pydantic), interactive Swagger docs, async support, and a clean `Depends()` injection system — making it ideal for demonstrating clean architecture concepts.

The Repository Pattern and Dependency Injection were introduced to enforce separation of concerns and make the storage layer swappable without touching business logic.

### How

- **Repository Pattern**: `StudentRepository` (ABC) defines the contract; `PostgresStudentRepository` implements it. `StudentService` only knows about the interface.
- **Dependency Injection**: `get_db_helper() → get_student_repository() → get_student_service()` wired via `Depends()`.
- **Lifespan**: `@asynccontextmanager` manages PostgreSQL connect on startup, disconnect on shutdown.
- **Global Error Handler**: `@app.exception_handler(ValueError)` catches all `ValueError`s and returns a clean `HTTP 400` JSON response.

### Where

```
app.py                          ← NEW: Uvicorn runner (separates server config from app logic)
main.py                         ← rewrote: FastAPI app, lifespan, routers, error handler
dependencies.py                 ← NEW: DI wiring module
routers/students.py             ← NEW: HTTP route definitions
services/student_service.py     ← NEW: business logic layer
repositories/student_repository.py  ← NEW: abstract + PostgreSQL implementation
database/database_helper.py     ← refactored: now managed by lifespan, not called directly
models/student.py               ← NEW: Pydantic Student model
schemas/student_schema.py       ← NEW: input sanitization
```

---

## v3–v6 — CLI Student Manager

**When:** Days 001–012  
**Theme:** Core Python fundamentals — data structures, OOP, file I/O, PostgreSQL basics

These versions were a terminal-based interactive menu application built purely in Python. They do not exist in the current codebase (superseded by v7).

| Version | Key Addition                                         |
| ------- | ---------------------------------------------------- |
| **v3**  | Basic list-based student storage; terminal menu loop |
| **v4**  | OOP refactor — `Student` class introduced            |
| **v5**  | File persistence (JSON / pickle)                     |
| **v6**  | PostgreSQL backend via `psycopg`; basic CRUD SQL     |
