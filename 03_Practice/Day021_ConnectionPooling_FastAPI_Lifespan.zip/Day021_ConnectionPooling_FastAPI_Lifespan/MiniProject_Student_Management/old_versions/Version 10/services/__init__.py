"""
Services package initialization.
"""
from services.student_service import StudentService

__all__ = ["StudentService"]
